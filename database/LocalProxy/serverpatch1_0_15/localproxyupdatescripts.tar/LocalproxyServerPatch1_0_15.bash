#!/bin/bash
#update version 1.0.15

if [[ $(grep -c 1.0.15 /usr/xhibit/onboot.sh) == 1 ]]; then
  echo System is already at build version 1.0.15
  echo No action performed.
  exit
fi

## Tomcat Restarting
# Remove old Tomcat Restart
crontab -u root -l | grep -v '/opt/moj/tomcat/bin/shutdown.sh' | crontab -u root -
crontab -u root -l | grep -v '/opt/moj/tomcat/bin/startup.sh' | crontab -u root -
# Add correct Tomcat Restarting ## Every morning at 4:00
(crontab -u root -l ; echo "0 4 * * * sudo -u tomcat /opt/moj/tomcat/bin/shutdown.sh") | crontab -u root -
(crontab -u root -l ; echo "1 4 * * * sudo -u tomcat /opt/moj/tomcat/bin/startup.sh") | crontab -u root -

# Add correct NTPd Restarting ## Every Sunday at 4:10
(crontab -u root -l ; echo "10 4 * * 0 /bin/systemctl restart ntpd.service") | crontab -u root -

# Add correct DHCPd Restarting ## Every Sunday at 4:11
(crontab -u root -l ; echo "11 4 * * 0 /bin/systemctl restart dhcpd.service") | crontab -u root -

# Add catalina.out to logrotate
sed -i '\/var\/log\/display-network.log/a \/opt\/moj\/tomcat\/logs\/catalina.out' /etc/logrotate.conf