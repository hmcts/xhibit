-- Localproxy Housekeeping - Script to be run monthly that clear out AUDIT records older than 90 days from current time.
-- Mapping Table only has createdDate and as such is measured from this
DELETE FROM AUD_MAPPING WHERE createdDate < SUBDATE(CURDATE(), INTERVAL 90 DAY);
-- All other tables have updatedDate and as such can be measured from this
DELETE FROM AUD_CDU WHERE updatedDate < SUBDATE(CURDATE(), INTERVAL 90 DAY);
DELETE FROM AUD_SITE WHERE updatedDate < SUBDATE(CURDATE(), INTERVAL 90 DAY);
DELETE FROM AUD_URL WHERE updatedDate < SUBDATE(CURDATE(), INTERVAL 90 DAY);