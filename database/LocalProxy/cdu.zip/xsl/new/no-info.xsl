<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

	<xsl:template match="/">
		<html>
			<head>
				<title>XHIBIT Displays</title>
				<!-- Setting up the variables to control the page rotation speeds | Will always curl with current index -->
				<meta http-equiv="refresh">
					<xsl:attribute name="content">
						<xsl:value-of select="/COURT/CDU/REFRESH"/><xsl:text>; index.php?macAddr=</xsl:text><xsl:value-of select="/COURT/CDU/MAC-ADDR"/><xsl:text>&amp;currentPageIndex=</xsl:text><xsl:value-of select="/COURT/PAGE/CURRENT-PAGE-INDEX"/>
					</xsl:attribute>
				</meta>
				
                <!-- Attaching Stylesheets -->
                <link rel="stylesheet" type="text/css">
					<xsl:attribute name="href">
						<xsl:text>css/new/notifications.css</xsl:text>
					</xsl:attribute>
				</link>
                <link rel="stylesheet" type="text/css">
					<xsl:attribute name="href">
						<xsl:text>css/new/general.css</xsl:text>
					</xsl:attribute>
				</link>
				<link rel="stylesheet" type="text/css">
					<xsl:attribute name="href">
						<xsl:text>css/new/table.css</xsl:text>
					</xsl:attribute>
				</link>
			</head>

			<body>

				<!-- POWERSAVING WINDOW -->
				<div id="brightnessWindow">
					<div id="powerSavingMessage">
						<xsl:if test="COURT/PAGE/LANGUAGE = 'English'">
							<span>- Power Saving Mode Enabled -</span>
						</xsl:if>
						<xsl:if test="COURT/PAGE/LANGUAGE = 'Welsh'">
							<span>- Power Arbed Modd Galluogwyd -</span>
						</xsl:if>
					</div>
				</div>
				<xsl:if test="COURT/CDU/POWER-SAVING = 'ENABLED'">
					<script>
						document.getElementById("brightnessWindow").style.visibility = "visible";
					</script>
				</xsl:if>

				<!-- NOTIFICATION BAR -->				
				<div class="notificationBar" id="notificationBar">
					<marquee>
						<div id="notificationContents">
							<xsl:value-of select="/COURT/CDU/NOTICE" />
						</div>
					</marquee>
				</div>

                <!-- TIME -->
                <div class="timeDisplay">
                    <span class="timeText"  id="time"></span>
                </div>

  				<!-- PAGE X OF Y (static) -->
				<div class="pageNumberDisplay">
					<xsl:if test="COURT/PAGE/LANGUAGE = 'English'">
						<span id="pageInfo" class="pageNumberText">1 of 1</span>
					</xsl:if>
					<xsl:if test="COURT/PAGE/LANGUAGE = 'Welsh'">
						<span id="pageInfo" class="pageNumberText">1 o 1</span>
					</xsl:if>
				</div>

                <!-- LOGO AND SITE TITLE -->
                <div id="heading" class="headerContainer">
                    <xsl:if test="COURT/PAGE/LANGUAGE = 'English'">
                        <span class="headerLogo">
							<img src="images/MoJLogo.png" alt="MoJ Logo" style="width: 100%;"></img>
						</span>
                    </xsl:if>
                    <xsl:if test="COURT/PAGE/LANGUAGE = 'Welsh'">
                        <span class="headerLogo">
							<img src="images/MoJLogoWelsh.png" alt="MoJ Logo" style="width: 100%;"></img>
						</span>
                    </xsl:if>
                    <span class="headerText">
						<xsl:if test="COURT/PAGE/LANGUAGE = 'English'">
							<xsl:value-of select="/COURT/CDU/SITE-TITLE"/>
						</xsl:if>
						<xsl:if test="COURT/PAGE/LANGUAGE = 'Welsh'">
							<xsl:value-of select="/COURT/CDU/SITE-TITLE-WELSH"/>
						</xsl:if>
                    </span>
                </div>

				<!-- TITLE, LAST UPDATED AND DEBUG INFORMATION -->
                <div id="pageTitle" class="title">
					<span>
						<xsl:value-of select="/COURT/CDU/LOCATION"/>
					</span>
					
					<div class="lastUpdated">
						<span id="lastUpdated">
							<xsl:if test="COURT/PAGE/LANGUAGE = 'English'">
								Last Updated:
							</xsl:if>
							<xsl:if test="COURT/PAGE/LANGUAGE = 'Welsh'">
								Diweddarwyd Ddiwethaf:
							</xsl:if>
							<xsl:value-of select="/COURT/PAGE/LAST-UPDATED" />
						</span>
						<span>
							<xsl:text> | </xsl:text>
						</span> 
                        <span>
							<xsl:if test="COURT/PAGE/LANGUAGE = 'English'">
								Version: 
							</xsl:if>
							<xsl:if test="COURT/PAGE/LANGUAGE = 'Welsh'">
								Fersiwn:
							</xsl:if>
							<xsl:text>CDU_</xsl:text>
							<xsl:value-of select="/COURT/CLIENT/VERSION" />
							<xsl:text> / </xsl:text>
							<xsl:text>PXY_</xsl:text>
							<xsl:value-of select="/COURT/CDU/VERSION" />
						</span>
						<span>
							<xsl:text> | </xsl:text>
						</span>
						<span>
							<xsl:value-of select="/COURT/CDU/TITLE"/>
						</span> 
					</div>
                </div>

				<!-- BODY -->
				<div id="bodyArea" class="body-area">
					<div class="noInformationContainer">
						<span class="noInformationToDisplayText">No Information To Display</span>
					</div>
				</div>

				<script type="text/javascript" src="onscreen-clock.js"></script>

			</body>
		</html>
	</xsl:template>
</xsl:stylesheet>