#!/bin/bash

USAGE="usage: $0 <IP address>"

if [ $# -lt 1 ]
then
    echo "ERROR: you must specify the local proxy IP address"
    echo $USAGE
    exit 1
fi

DB_USER=xhibit
DB_PASSWORD=xhibit
DB_STRING=@O10TST2

IP_ADDRESS=$1

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)

sqlplus -S $DB_USER/$DB_PASSWORD$DB_STRING <<EOF
@$SCRIPT_DIR/pdm_localproxy_errors.sql $IP_ADDRESS
EOF
