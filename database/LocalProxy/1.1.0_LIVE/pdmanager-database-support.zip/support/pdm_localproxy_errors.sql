set linesize 132
set pagesize 0
set echo off
set serveroutput on
set feedback off
set show off
set verify off
column MESSAGE_ERROR format a300
column MESSAGE_ID format a40
column SERVICE format a30
column CREATION_TIME format a30

  def PARAM1=&1

  SELECT TO_CHAR(CREATION_DATE, 'yyyy-mm-dd hh24:mi:ss') AS CREATION_TIME, SERVICE, MESSAGE_ID, dbms_lob.substr(MESSAGE_RESPONSE,500) AS MESSAGE_ERROR
  FROM XHB_DISP_MGR_SERVICE_AUDIT
  WHERE MESSAGE_STATUS = 'FAILED' AND URL LIKE '%/&PARAM1/%'
  ORDER BY CREATION_DATE ASC;

exit
