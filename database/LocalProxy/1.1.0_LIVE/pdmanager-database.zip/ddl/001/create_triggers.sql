ALTER SESSION SET current_schema=xhibit;

PROMPT BEGINNING-create_triggers

PROMPT beginning-DM_COURT_SITE_BUR_TR -create_triggers
CREATE OR REPLACE TRIGGER DM_COURT_SITE_BUR_TR
  BEFORE UPDATE OR DELETE
  ON XHB_DISP_MGR_COURT_SITE
  FOR EACH ROW

DECLARE

  l_trig_event VARCHAR2(1) := NULL;

  OPTIMISTIC_LOCK_PROB EXCEPTION;
  PRAGMA EXCEPTION_INIT(OPTIMISTIC_LOCK_PROB, -20101);

BEGIN

	/* Determine whether UPDATING or DELETING */
	IF UPDATING THEN

		l_trig_event := 'U';

		/* If the user is the connection pool user as defined in XHB_SYS_USER_INFORMATION */
		IF (XHB_CUSTOM_PKG.IS_CONNECTION_POOL_USER = 1) THEN
		  IF (:OLD.VERSION != :NEW.VERSION) THEN
		    /* Someone has pulled the rug out from below! */
		    RAISE OPTIMISTIC_LOCK_PROB;
		  END IF;
		END IF;

		/* Increment version and set updated date to now */
		SELECT :OLD.VERSION + 1,
			   SYSDATE
		INTO   :NEW.VERSION,
			   :NEW.LAST_UPDATE_DATE
		FROM   DUAL;

		/* If the user is not the connection pool user as defined in XHB_SYS_USER_INFORMATION */
		IF (XHB_CUSTOM_PKG.IS_CONNECTION_POOL_USER = 0) THEN
		  SELECT SYS_CONTEXT('USERENV', 'SESSION_USER')
		  INTO   :NEW.LAST_UPDATED_BY
		  FROM   DUAL;
		END IF;

	ELSE -- Must be DELETING

		l_trig_event := 'D';

	END IF;

	/* Is Auditing on this table required */
	IF (XHB_CUSTOM_PKG.IS_AUDIT_REQUIRED('XHB_DISP_MGR_COURT_SITE') = 1) THEN
		INSERT INTO AUD_DISP_MGR_COURT_SITE 
		VALUES (:old.COURT_SITE_ID, 
				:old.TITLE, 
				:old.PAGE_URL, 
				:old.SCHEDULE_ID,
				:old.XHIBIT_COURT_SITE_ID,
				:old.LAST_UPDATE_DATE, 
				:old.CREATION_DATE, 
				:old.CREATED_BY, 
				:old.LAST_UPDATED_BY, 
				:old.VERSION,
				l_trig_event,
				:old.RAG_STATUS,
				:old.RAG_STATUS_DATE,
				:old.NOTIFICATION);
	END IF;

END;
/
PROMPT ending-DM_COURT_SITE_BUR_TR -create_triggers

PROMPT beginning-DM_SERVICE_AUDIT_BIR_TR -create_triggers
CREATE OR REPLACE TRIGGER DM_SERVICE_AUDIT_BIR_TR
  BEFORE INSERT
  ON XHB_DISP_MGR_SERVICE_AUDIT
  FOR EACH ROW

BEGIN

	/* If ID not supplied, get next from sequence */
	IF :NEW.SERVICE_AUDIT_ID IS NULL THEN
	  SELECT	DM_SERVICE_AUDIT_SEQ.NEXTVAL
	  INTO		:NEW.SERVICE_AUDIT_ID
	  FROM DUAL;
	END IF;

	/* If created by and updated by not supplied, set it to session user */
	IF ((:NEW.LAST_UPDATED_BY IS NULL)
	   OR (:NEW.CREATED_BY IS NULL) ) THEN
	  SELECT	SYS_CONTEXT('USERENV', 'SESSION_USER'),
				SYS_CONTEXT('USERENV', 'SESSION_USER')
	  INTO   	:NEW.LAST_UPDATED_BY,
				:NEW.CREATED_BY 
	  FROM DUAL;
	END IF;

	/* Set created date and updated date to now and version to one */
	SELECT	SYSDATE,
			SYSDATE,
			1
	INTO	:NEW.LAST_UPDATE_DATE, 
			:NEW.CREATION_DATE,
			:NEW.VERSION
	FROM DUAL;

END;
/
PROMPT ending-DM_SERVICE_AUDIT_BIR_TR -create_triggers

PROMPT ENDING-create_triggers
