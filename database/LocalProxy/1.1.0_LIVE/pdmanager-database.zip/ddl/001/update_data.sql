ALTER SESSION SET current_schema=xhibit;

--Update all existing users to admins
UPDATE XHB_DISP_MGR_USER_DETAILS SET USER_ROLE = 'ROLE_ADMIN';

--Default court site rag status to green
UPDATE XHB_DISP_MGR_COURT_SITE SET RAG_STATUS = 'G'
WHERE RAG_STATUS IS NULL;

--Default court site rag status date to creation date
UPDATE XHB_DISP_MGR_COURT_SITE SET RAG_STATUS_DATE = CREATION_DATE
WHERE RAG_STATUS_DATE IS NULL;

--Default local proxy rag status date to creation date
UPDATE XHB_DISP_MGR_LOCAL_PROXY SET RAG_STATUS_DATE = CREATION_DATE
WHERE RAG_STATUS_DATE IS NULL;

--Default cdu rag status date to creation date
UPDATE XHB_DISP_MGR_CDU SET RAG_STATUS_DATE = CREATION_DATE
WHERE RAG_STATUS_DATE IS NULL;

--Update title of single existing power save
UPDATE XHB_DISP_MGR_SCHEDULE SET TITLE = 'Mon-Fri 08:00-18:00'
WHERE SCHEDULE_ID = 1;

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Mon-Fri 07:00-19:00', '[{ "priority" : 51,  "label" : "Weekends",  "day" :["Saturday", "Sunday" ],   "schedule" : [{ "from" : "00:00", "to" : "23:59" }]},{ "priority" : 52,  "label" : "Weekdays",  "day" :["Monday", "Tuesday", "Wednesday", "Thursday", "Friday" ],   "schedule" : [{ "from" : "00:00", "to" : "06:59" }, { "from" : "19:00", "to" : "23:59" }]}]');

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Mon-Fri 08:00-18:30', '[{ "priority" : 51,  "label" : "Weekends",  "day" :["Saturday", "Sunday" ],   "schedule" : [{ "from" : "00:00", "to" : "23:59" }]},{ "priority" : 52,  "label" : "Weekdays",  "day" :["Monday", "Tuesday", "Wednesday", "Thursday", "Friday" ],   "schedule" : [{ "from" : "00:00", "to" : "07:59" }, { "from" : "18:30", "to" : "23:59" }]}]');

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Mon-Fri 09:00-17:00', '[{ "priority" : 51,  "label" : "Weekends",  "day" :["Saturday", "Sunday" ],   "schedule" : [{ "from" : "00:00", "to" : "23:59" }]},{ "priority" : 52,  "label" : "Weekdays",  "day" :["Monday", "Tuesday", "Wednesday", "Thursday", "Friday" ],   "schedule" : [{ "from" : "00:00", "to" : "08:59" }, { "from" : "17:00", "to" : "23:59" }]}]');

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Mon-Sat 08:00-18:30', '[{ "priority" : 51,  "label" : "Weekends",  "day" :["Sunday" ],   "schedule" : [{ "from" : "00:00", "to" : "23:59" }]},{ "priority" : 52,  "label" : "Weekdays",  "day" :["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ],   "schedule" : [{ "from" : "00:00", "to" : "07:59" }, { "from" : "18:30", "to" : "23:59" }]}]');

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Mon-Sun 00:00-23:59', '[{ "priority" : 52,  "label" : "Weekdays",  "day" :["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],   "schedule" : [{ "from" : "00:00", "to" : "00:01" }, { "from" : "23:59", "to" : "00:00" }]}]');

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Mon-Sun 08:00-18:30', '[{ "priority" : 52,  "label" : "Weekdays",  "day" :["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" ],   "schedule" : [{ "from" : "00:00", "to" : "07:59" }, { "from" : "18:30", "to" : "23:59" }]}]');

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Mon-Thu 08:00-18:30', '[{ "priority" : 51,  "label" : "Weekends",  "day" :["Friday", "Saturday", "Sunday" ],   "schedule" : [{ "from" : "00:00", "to" : "23:59" }]},{ "priority" : 52,  "label" : "Weekdays",  "day" :["Monday", "Tuesday", "Wednesday", "Thursday" ],   "schedule" : [{ "from" : "00:00", "to" : "07:59" }, { "from" : "18:30", "to" : "23:59" }]}]');

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Tue-Fri 08:00-18:30', '[{ "priority" : 51,  "label" : "Weekends",  "day" :["Monday", "Saturday", "Sunday" ],   "schedule" : [{ "from" : "00:00", "to" : "23:59" }]},{ "priority" : 52,  "label" : "Weekdays",  "day" :["Tuesday", "Wednesday", "Thursday", "Friday" ],   "schedule" : [{ "from" : "00:00", "to" : "07:59" }, { "from" : "18:30", "to" : "23:59" }]}]');

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Tue-Thu 08:00-18:30', '[{ "priority" : 51,  "label" : "Weekends",  "day" :["Monday", "Friday", "Saturday", "Sunday" ],   "schedule" : [{ "from" : "00:00", "to" : "23:59" }]},{ "priority" : 52,  "label" : "Weekdays",  "day" :["Tuesday", "Wednesday", "Thursday" ],   "schedule" : [{ "from" : "00:00", "to" : "07:59" }, { "from" : "18:30", "to" : "23:59" }]}]');

--Insert new power save schedule
INSERT INTO XHB_DISP_MGR_SCHEDULE (
SCHEDULE_TYPE
,TITLE
,DETAIL
)
VALUES ('POWER_SAVE', 'Wed-Thu 08:00-18:30', '[{ "priority" : 51,  "label" : "Weekends",  "day" :["Monday", "Tuesday", "Friday", "Saturday", "Sunday" ],   "schedule" : [{ "from" : "00:00", "to" : "23:59" }]},{ "priority" : 52,  "label" : "Weekdays",  "day" :["Wednesday", "Thursday" ],   "schedule" : [{ "from" : "00:00", "to" : "07:59" }, { "from" : "18:30", "to" : "23:59" }]}]');

COMMIT;