-- Write script output to file
SPOOL install.lst

PROMPT -- Running common install scripts --
@@install_common

PROMPT -- Running environment specific scripts
@@insert_properties_dev

-- Turn off writing to file
SPOOL OFF