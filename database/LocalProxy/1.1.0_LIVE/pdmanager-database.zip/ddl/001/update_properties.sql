ALTER SESSION SET current_schema=xhibit;

--Update configuration property names
UPDATE XHB_DISP_MGR_PROPERTY SET PROPERTY_NAME = 'rag.status.courtsite.red.percent'
WHERE PROPERTY_NAME = 'rag.status.localproxy.red.percent';

UPDATE XHB_DISP_MGR_PROPERTY SET PROPERTY_NAME = 'rag.status.courtsite.amber.percent'
WHERE PROPERTY_NAME = 'rag.status.localproxy.amber.percent';

COMMIT;