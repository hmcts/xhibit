ALTER SESSION SET current_schema=xhibit;

PROMPT BEGINNING-drop_sequences

PROMPT beginning-DM_SERVICE_AUDIT_SEQ -drop_sequences
DROP SEQUENCE DM_SERVICE_AUDIT_SEQ;
PROMPT ending-DM_SERVICE_AUDIT_SEQ -drop_sequences

PROMPT ENDING-drop_sequences