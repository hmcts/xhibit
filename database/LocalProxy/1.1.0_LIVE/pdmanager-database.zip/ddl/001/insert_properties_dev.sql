ALTER SESSION SET current_schema=xhibit;

--DEV configuration property values
PROMPT beginning-XHB_DISP_MGR_PROPERTY ('rag.status.update.threads') -insert_properties_dev
INSERT INTO XHB_DISP_MGR_PROPERTY (
PROPERTY_NAME
,PROPERTY_VALUE
)
VALUES ('rag.status.update.threads', '5');
PROMPT ending-XHB_DISP_MGR_PROPERTY ('rag.status.update.threads') -insert_properties_dev

PROMPT beginning-XHB_DISP_MGR_PROPERTY ('rag.status.update.cron') -insert_properties_dev
INSERT INTO XHB_DISP_MGR_PROPERTY (
PROPERTY_NAME
,PROPERTY_VALUE
)
VALUES ('rag.status.update.cron', '0 0 * * * ?');
PROMPT ending-XHB_DISP_MGR_PROPERTY ('rag.status.update.cron') -insert_properties_dev

PROMPT beginning-XHB_DISP_MGR_PROPERTY ('rag.status.reload.interval') -insert_properties_dev
INSERT INTO XHB_DISP_MGR_PROPERTY (
PROPERTY_NAME
,PROPERTY_VALUE
)
VALUES ('rag.status.reload.interval', '900');
PROMPT ending-XHB_DISP_MGR_PROPERTY ('rag.status.reload.interval') -insert_properties_dev

COMMIT;