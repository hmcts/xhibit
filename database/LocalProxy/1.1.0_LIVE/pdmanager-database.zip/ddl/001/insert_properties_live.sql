ALTER SESSION SET current_schema=xhibit;

--LIVE configuration property values
PROMPT beginning-XHB_DISP_MGR_PROPERTY ('rag.status.update.threads') -insert_properties_live
INSERT INTO XHB_DISP_MGR_PROPERTY (
PROPERTY_NAME
,PROPERTY_VALUE
)
VALUES ('rag.status.update.threads', '5');
PROMPT ending-XHB_DISP_MGR_PROPERTY ('rag.status.update.threads') -insert_properties_live

PROMPT beginning-XHB_DISP_MGR_PROPERTY ('rag.status.update.cron') -insert_properties_live
INSERT INTO XHB_DISP_MGR_PROPERTY (
PROPERTY_NAME
,PROPERTY_VALUE
)
VALUES ('rag.status.update.cron', '0 */3 * * * ?');
PROMPT ending-XHB_DISP_MGR_PROPERTY ('rag.status.update.cron') -insert_properties_live

PROMPT beginning-XHB_DISP_MGR_PROPERTY ('rag.status.reload.interval') -insert_properties_live
INSERT INTO XHB_DISP_MGR_PROPERTY (
PROPERTY_NAME
,PROPERTY_VALUE
)
VALUES ('rag.status.reload.interval', '180');
PROMPT ending-XHB_DISP_MGR_PROPERTY ('rag.status.reload.interval') -insert_properties_live

COMMIT;