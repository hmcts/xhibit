#!/bin/bash
#update version 1.0.14

## DHCP Fix
if [[ $(grep -c 1.0.14 /usr/xhibit/onboot.sh) == 1 ]]; then
  echo System is already at build version 1.0.14
  echo No action performed.
  exit
fi
#dhcpd
sed -i 's/#authoritative;/authoritative;/' /etc/dhcp/dhcpd.conf 
sed  -i 's#execute("/opt/xhibit/bind_ip.sh", clhw, clip);##' /etc/dhcp/dhcpd.conf

#Drop logs
chmod +w /var/spool/cron/root
sed -i 's#*/10 * * * * /usr/bin/cgi-cdu-transferLogs.sh#*/10 * * * * /usr/bin/cgi-cdu-transferLogs.sh >/dev/null#' /var/spool/cron/root
chmod -w /var/spool/cron/root

#onboot.sh 
chmod +w /usr/xhibit/onboot.sh
sed -i 's/1.0.13/1.0.14/' /usr/xhibit/onboot.sh
sed  -i "13i sleep 15" /usr/xhibit/onboot.sh
sed  -i "14i systemctl restart dhcpd.service" /usr/xhibit/onboot.sh
chmod -w /usr/xhibit/onboot.sh

systemctl restart dhcpd.service
systemctl status dhcpd.service

## Tomcat Restart Cron & Download Updates Cron
# Remove old DownloadUpdates
crontab -u root -l | grep -v '/usr/bin/DownloadUpdates.sh'  | crontab -u root -
# Add correct DownloadUpdates
(crontab -u root -l ; echo "0 23 * * * /usr/bin/DownloadUpdates.sh") | crontab -u root -
# Add new "Tomcat Start / Stop"
(crontab -u root -l ; echo "0 4 1 * * su tomcat -c '/opt/moj/tomcat/bin/shutdown.sh'") | crontab -u root -
(crontab -u root -l ; echo "1 4 1 * * su tomcat -c '/opt/moj/tomcat/bin/startup.sh'") | crontab -u root -