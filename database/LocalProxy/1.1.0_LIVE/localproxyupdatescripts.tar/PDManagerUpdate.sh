#!/bin/bash
#
# This script is to be used to deploy a new PDManager.war and .properties file onto the
# Localproxy, this assumes there is already an instance of tomcat running in advance.
#
# Created by: Sean Bulley
# Created on: 31/05/2017 (dd/mm/yyyy)
#

LOCK_FILE=/tmp/PDManagerUpdate.lock
LOG_TO_CONSOLE=0

function logInfo {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."
	`${LOGGER_COMMAND}info \"${MSG}\"`
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ${MSG}"
	fi
}

function logError {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."
	`${LOGGER_COMMAND}err \"${MSG}\"`
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ERROR: ${MSG}"
	fi
}

# first check if this script is already running by checking for lock file
if [[ -f ${LOCK_FILE} ]]; then
    echo "Lock file exists - already running"
	exit 1
fi

# create lock file to prevent re-entry
touch ${LOCK_FILE}

if [[ "$1" == "--report" ]]; then
	LOG_TO_CONSOLE=1
fi

#################################################

# step 1 - delete existing war file while tomcat is running, then wait 30s
logInfo "Deleting existing ipdmanager.war"
rm -f /opt/moj/tomcat/webapps/ipdmanager.war
logInfo "War deleted, waiting 30 seconds"
sleep 30

# step 2 - wait until application had undeployed, maximum wait of 5 minutes, checking every 30s
for (( c=1; c<=9; c++ ))
do  
	logInfo "Checking if undeployed - check number = $c"
	if [ ! -d "/opt/moj/tomcat/webapps/ipdmanager" ];
	then
		# if doesn't exist then undeployed - move on
		break
	fi
	logInfo "ipdmanager Directory still exists, waiting 30s before next check"
	sleep 30
done

# step 3 - stop tomcat
logInfo "stopping Tomcat"
tomcat stop

# step 4 - force delete ipdmanager directory if still exists
if [ -d "/opt/moj/tomcat/webapps/ipdmanager" ];
then
	logInfo "ERROR: Tomcat didn't undeploy old IPDManager.war successfully, force deleting ipdmanager directory"
	# if directory exists then force delete
	rm -rf /opt/moj/tomcat/webapps/ipdmanager
fi

# step 5 - copy ipdmanager.properties into conf and setting permissions
logInfo "Copying in new ipdmanager.properties"
cp /usr/xhibit/updates/ipdmanager.properties /opt/moj/tomcat/conf/ipdmanager.properties
chown tomcat.root /opt/moj/tomcat/conf/ipdmanager.properties
chmod 664 /opt/moj/tomcat/conf/ipdmanager.properties

# step 6 - copy ipdmanager.war to webapps and set permissions
logInfo "Copying in new ipdmanager.war"
cp /usr/xhibit/updates/ipdmanager.war /opt/moj/tomcat/webapps/ipdmanager.war
chown tomcat.root /opt/moj/tomcat/webapps/ipdmanager.war
chmod 664 /opt/moj/tomcat/webapps/ipdmanager.war

# step 7 - start tomcat
logInfo "starting Tomcat"
tomcat start

#################################################

logInfo "Removing lock file, deployment finished"
# clean up the lock file
rm -f ${LOCK_FILE}

# finally, mark as successful
logInfo "Deployment script run successfully"