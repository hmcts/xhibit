#!/bin/bash
#
# This script deploys the updates downloaded earlier on.
# The support team must use the switches below to state the updates required.
#
# Created by: Sean Bulley
# Created on: 02/02/2017 (dd/mm/yyyy)
#
# Version History
# Date          Name                        Description
# 02/02/2017    Sean Bulley                 First issue
#

######################
## UPDATES TO APPLY ##
######################
UPDATE_DATABASE=false
UPDATE_MANAGER=true
UPDATE_MANAGERSCRIPTS=false
UPDATE_CDU=true
UPDATE_LOCALPROXY=true

##############################################################################
LOCK_FILE=/tmp/installupdatemanager.lock


LOG_TO_CONSOLE=0

function logInfo {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}info \"${MSG}\"`
	
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ${MSG}"
	fi
}

function logError {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}err \"${MSG}\"`
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ERROR: ${MSG}"
	fi
}


# first check if this script is already running by checking for lock file
if [[ -f ${LOCK_FILE} ]]; then
    echo "Lock file for localproxyUpdateScripts.tar exists - already running"
	exit 1
fi

# create lock file to prevent re-entry
touch ${LOCK_FILE}

if [[ "$1" == "--report" ]]; then
	LOG_TO_CONSOLE=1
fi

##################
###### MAIN ######
##################

logInfo "Starting the update script"

## Database Update Script
if [ "$UPDATE_DATABASE" = true ]; then
	logInfo ""
	logInfo "Update Database True, running DBUpdate.sh"
    sh /usr/bin/DBUpdate.sh
	logInfo "DBUpdate.sh Run"
fi

## Manager Application Update
if [ "$UPDATE_MANAGER" = true ]; then
	logInfo ""
	logInfo "Update Manager True, running PDManagerUpdatee.sh"
    sh /usr/bin/PDManagerUpdate.sh
	logInfo "PDManagerUpdate.sh Run"
fi

## Manager Scripts Update
if [ "$UPDATE_MANAGERSCRIPTS" = true ]; then
	logInfo ""
	logInfo "Update Manager Scripts True, running ManagerScriptsUpdate.sh"
    sh /usr/bin/ManagerScriptsUpdate.sh
	logInfo "ManagerScriptsUpdate.sh Run"
fi

## CDU Application Update
if [ "$UPDATE_CDU" = true ]; then
	logInfo ""
	logInfo "Update CDU Application, running CDUApplicationUpdate.sh"
    sh /usr/bin/CDUApplicationUpdate.sh
	logInfo "CDUApplicationUpdate.sh Run"
fi

## Localproxy Application Update
if [ "$UPDATE_LOCALPROXY" = true ]; then
	logInfo ""
	logInfo "Update Localproxy Application True, runningLocalproxyApplicationUpdate.sh"
    sh /usr/bin/LocalproxyApplicationUpdate.sh
	logInfo "LocalproxyApplicationUpdate.sh Run"
fi

## At the end of the update process
logInfo "Reached the end of the update script"
logInfo "copying back clean install script"

# clean up the lock file
rm -f ${LOCK_FILE}

cp /usr/bin/InstallUpdateManagerALLOFF.sh /usr/bin/InstallUpdateManager.sh

