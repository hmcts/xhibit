#!/bin/bash
#
#  This is a script which polls the Central XHIBIT Server for a managerApp
#  release. On availability of a new release, it downloads the release,
#  verifying the release against checksum and copys the release onto the Localproxy.
#
# Created by: Sean Bulley
# Created on: 15/12/2016 (dd/mm/yyyy)
#
# Version History
# Date          Name                        Description
# 15/12/2016    Sean Bulley                 First issue
# 06/02/2017	Sean Bulley					Updated to reflect new Script Manager Design
#

#########################
#########################

LOCK_FILE=/tmp/ManagerApplicationUpdate.lock
APPLICATION_DOWNLOAD_LOCATION=/usr/xhibit/updates/ipdmanager.war
CHECKSUM_LOCATION=/opt/updatechecksums/ipdmanager.war.sha1
LATEST_CHECKSUM=`cat ${CHECKSUM_LOCATION}`

LOG_TO_CONSOLE=0

function logInfo {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}info \"${MSG}\"`
	
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ${MSG}"
	fi
}

function logError {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}err \"${MSG}\"`
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ERROR: ${MSG}"
	fi
}

# first check if this script is already running by checking for lock file
if [[ -f ${LOCK_FILE} ]]; then
    echo "Lock file exists - already running"
	exit 1
fi

# create lock file to prevent re-entry
touch ${LOCK_FILE}

if [[ "$1" == "--report" ]]; then
	LOG_TO_CONSOLE=1
fi

cd /opt/moj/tomcat/webapps

# remove existing backup
rm -f ipdmanager.war.backup 
 
# backup the old .war
mv -f ipdmanager.war ipdmanager.war.backup
	
# wait 30 seconds for old app to undeploy
sleep 30 

# stop tomcat
tomcat stop

sleep 30 

# copy the new war in
cp /usr/xhibit/updates/ipdmanager.war .

sleep 30 

# restart tomcat
tomcat start
sleep 60

tomcat stop
sleep 60 
tomcat start
sleep 30 
	
# finally, mark as successful
logInfo "Deployment successful"


# clean up the lock file
rm -f ${LOCK_FILE}
