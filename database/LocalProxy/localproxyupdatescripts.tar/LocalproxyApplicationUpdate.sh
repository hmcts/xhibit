#!/bin/bash
#
# This is a script that updates the localproxy applciation
#
# Created by: Sean Bulley
# Created on: 15/02/2017 (dd/mm/yyyy)

#########################
#########################

LOCK_FILE=/tmp/LocalproxyUpdater.lock
APPLICATION_DOWNLOAD_LOCATION=/usr/xhibit/updates/localproxy.tar
CHECKSUM_LOCATION=/opt/updatechecksums/localproxy.tar.sha1
LATEST_CHECKSUM=`cat ${CHECKSUM_LOCATION}`
WORKING_DIR=/tmp/localproxy-app

LOG_TO_CONSOLE=0

function logInfo {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}info \"${MSG}\"`
	
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ${MSG}"
	fi
}

function logError {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}err \"${MSG}\"`
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ERROR: ${MSG}"
	fi
}

# first check if this script is already running by checking for lock file
if [[ -f ${LOCK_FILE} ]]; then
    echo "Lock file exists - already running"
	exit 1
fi

# create lock file to prevent re-entry
touch ${LOCK_FILE}

if [[ "$1" == "--report" ]]; then
	LOG_TO_CONSOLE=1
fi

logInfo "Deploying new proxy application release with checksum ${LATEST_CHECKSUM}"

# backup existing fodler
mv /var/www/court-display/proxy /var/www/court-display/proxy.backup
mv /var/www/court-display/proxycode /var/www/court-display/proxycode.backup

mkdir -p /var/www/court-display/proxy
mkdir -p /var/www/court-display/proxycode

	
# move the tarball to target directory
cp ${APPLICATION_DOWNLOAD_LOCATION} /var/www/court-display

tar -xvf /var/www/court-display/localproxy.tar -C /var/www/court-display

rm /var/www/court-display/localproxy.tar

# ensure all files are owned by www-data
chown -R apache:apache /var/www/court-display

# clear the working directory
rm -rf ${WORKING_DIR}

# finally, mark as successful
logInfo "Deployment successful"


# clean up the lock file
rm -f ${LOCK_FILE}
