#!/bin/bash
#
# This is a script that downloads and extracts the other update scripts
#
# Created by: Sean Bulley
# Created on: 15/02/2017 (dd/mm/yyyy)

#########################
#########################

CHECKSUM_DOWNLOAD_URL=http://xhibitdisplay/pdmanager/pdm/software/checksum/
APPLICATION_DOWNLOAD_URL=http://xhibitdisplay/pdmanager/pdm/software/download/
LOCK_FILE=/tmp/LocalproxyScriptUpdater.lock
WORKING_DIR=/usr/xhibit/updates

LOG_TO_CONSOLE=0

function logInfo {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}info \"${MSG}\"`
	
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ${MSG}"
	fi
}

function logError {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}err \"${MSG}\"`
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ERROR: ${MSG}"
	fi
}

### Function to determine if checksum is valid
function isValidChecksum() {
	case $1 in
		( *[!0-9A-Fa-f]* | "" ) return 1;;
		( * )
			case ${#1} in
				( 32 | 40 ) return 0 ;;
				( * ) return 1 ;;
			esac
	esac
}

######################################

### Function to deal with the download process for each file
### Expects to be called downloadUpdates FILENAME PATHTOCHECKSUM
function downloadUpdate() {
	## because it's likely this is the first script to run, going to establish checksum directory
	mkdir -p /opt/updatechecksums
	logInfo "##### Evaluating Download for ${1} #####"
	logInfo "Getting NEW checksum for ${1}"
	logInfo "Calling to ${CHECKSUM_DOWNLOAD_URL}${1} for checksum for ${1}"
	NEWCHECKSUM=""
	NEWCHECKSUM=`/usr/bin/curl ${CHECKSUM_DOWNLOAD_URL}${1} 2>/dev/null`
	if isValidChecksum $NEWCHECKSUM; then
		logInfo "Got NEW checksum for ${1} as: ${NEWCHECKSUM}"
	else
		logInfo "Got INVALID checksum for ${1} - skipping file"
		NEWCHECKSUM=""
	fi

	# Check if NEWCHECKSUM is present
	if [ "$NEWCHECKSUM" == "" ]; then
		# NO CHECKSUM - must be no new release
		logInfo "Checksum for ${1} was blank - No Release Available"
	else
		# Now compare with the current checksum
		logInfo "Getting OLD checksum for ${1} from file ${2}"
		if [ -f "$2" ]; then
			OLDCHECKSUM=`cat "${2}"`
			logInfo "Checksum file for ${1} found - gave checksum of ${OLDCHECKSUM}"
		else
			# No checksum found - create a default empty checksum
			logInfo "Checksum file not found - giving checksum of NULL"
			OlDCHECKSUM=""
		fi
		
		# Evaluate if new file should download
		logInfo "Evaluating Checksums: OLD: ${OLDCHECKSUM} vs NEW: ${NEWCHECKSUM}"
		if [[ "${OLDCHECKSUM}" != "${NEWCHECKSUM}" ]]; then
			logInfo "Checksums Different - Downloading New Version of ${1}"
			# Set the new checksum as the latest one
			echo ${NEWCHECKSUM} > ${2}

			if [[ ! -d ${WORKING_DIR} ]]; then
				mkdir ${WORKING_DIR}
			fi

			if [[ -f ${WORKING_DIR}/${1} ]]; then
				rm -f ${WORKING_DIR}/${1}
			fi

			`/usr/bin/curl -o ${WORKING_DIR}/${1} ${APPLICATION_DOWNLOAD_URL}{$1} 2>/dev/null`

			## File now downloaded - double check this is valid
			logInfo "New ${1} has downloaded - validating checksum of new file"
			DOWNLOADCHECKSUM=($(sha1sum ${WORKING_DIR}/${1}))
			echo ${DOWNLOADCHECKSUM}
			logInfo "Downloaded file has checksum of ${DOWNLOADCHECKSUM}"
			
			# Evaluate that download checksum is same as expected
			if [[ "${DOWNLOADCHECKSUM}" == "${NEWCHECKSUM}" ]]; then
				# File is confirmed as good
				logInfo "Checksum for NEW ${1} confirmed good"
				
				## Now to extract
				
				logInfo "Extracting Scripts to /usr/bin"
				logInfo "Make Directory to extract files into, and extract files"
				mkdir ${WORKING_DIR}/tempscriptextraction
				mv ${WORKING_DIR}/${1} /${WORKING_DIR}/tempscriptextraction/.
				cd ${WORKING_DIR}/tempscriptextraction/
				tar -xvf ${1}
				logInfo "Scripts extracted - deleting source tar"
				rm -f ${1}
				logInfo "Moving all scripts to /usr/bin/."
				mv * /usr/bin/.
				logInfo "Moved all scripts to /usr/bin/. - deleting temp dir"
				cd ..
				rm -rf tempscriptextraction
				
			else
				# Checksum doesn't match expected
				logInfo "Checksum for NEW ${1} doesn't match expected for ${1}"
				logInfo "Downloaded: ${DOWNLOADCHECKSUM} vs NEW: ${NEWCHECKSUM}"
				logInfo "Reverting local checksum to old version and deleting downloaded file"
				echo ${OLDCHECKSUM} > ${2}
				rm -f {$WORKING_DIR}/{$1}
				# Reverted back to before download was called
				logInfo "Reverted back for ${1} download"
			fi
		else
			# Checksum hasn't changed - no new download present
			logInfo "Checksums for ${1} are the same - No new release for ${1}"
		fi
	fi
	
	# Log a blank line (looks cleaner)
	logInfo ""	
}

#######################

### First check if this script is already running by checking for lock file
if [[ -f ${LOCK_FILE} ]]; then
    logInfo "Lock file for LocalproxyScriptUpdater exists - already running or crashed previously"
	exit 1
fi

### Create lock file to prevent re-entry
touch ${LOCK_FILE}

### Calls to Download Function
### Should be passed downloadUpdate FILENAME CHECKSUMLOCATION
logInfo "##### - Beginning Download Process - #####"
downloadUpdate localproxyupdatescripts.tar /opt/updatechecksums/localproxyupdatescripts.tar.sha1

### Downloading Finished - Clean up the lock file
rm -f ${LOCK_FILE}

### Download Script Finished, log end and exit
logInfo "Downloading Script Ended - Exiting"
