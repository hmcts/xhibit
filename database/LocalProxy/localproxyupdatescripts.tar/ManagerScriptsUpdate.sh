#!/bin/bash
#
# This is a script that runs SQL code to provice updates to the XHIBIT Displays database
#
# Created by: Sean Bulley
# Created on: 15/12/2016 (dd/mm/yyyy)
#
# Version History
# Date          Name                        Description
# 06/02/2017	Sean Bulley					First Issue
#

#########################
#########################

LOCK_FILE=/tmp/cgi-manager-scripts-update.lock
APPLICATION_DOWNLOAD_LOCATION=/usr/xhibit/updates/ipdmanager.tar
CHECKSUM_LOCATION=/opt/updatechecksums/ipdmanager.tar.sha1
LATEST_CHECKSUM=`cat ${CHECKSUM_LOCATION}`
WORKING_DIR=/tmp/ipdmanagerscripts/

LOG_TO_CONSOLE=0

function logInfo {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}info \"${MSG}\"`
	
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ${MSG}"
	fi
}

function logError {
	MSG=$1
	LOGGER_COMMAND="/usr/bin/logger -p local5."

	`${LOGGER_COMMAND}err \"${MSG}\"`
	if [[ ${LOG_TO_CONSOLE} ]]; then
		echo ". ERROR: ${MSG}"
	fi
}

# first check if this script is already running by checking for lock file
if [[ -f ${LOCK_FILE} ]]; then
    echo "Lock file exists - already running"
	exit 1
fi

# create lock file to prevent re-entry
touch ${LOCK_FILE}

if [[ "$1" == "--report" ]]; then
	LOG_TO_CONSOLE=1
fi

logInfo "Deploying new manager scripts release with checksum ${LATEST_CHECKSUM}"

mkdir /tmp/ipdmanagerscripts
	
# move the tarball to target directory
cp ${APPLICATION_DOWNLOAD_LOCATION} ${WORKING_DIR}.

# unpack tar into working dir
tar -xvf ${WORKING_DIR}ipdmanager.tar -C /usr/bin

# remove tar
#rm ${WORKING_DIR}ipdmanager.tar

# copy contents of working dir into usr bin
cp ${WORKING_DIR}* /usr/bin/.

## clear the working directory
#rm -rf ${WORKING_DIR}

# finally, mark as successful
logInfo "Deployment successful"


# clean up the lock file
rm -f ${LOCK_FILE}
