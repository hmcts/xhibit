-- Write script output to file
SPOOL install.lst

PROMPT -- Running scripts --
@@create_packages

-- Turn off writing to file
SPOOL OFF